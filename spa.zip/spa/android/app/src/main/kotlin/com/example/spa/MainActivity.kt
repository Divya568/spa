package com.example.spa

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
