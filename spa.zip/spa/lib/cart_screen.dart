import 'package:flutter/material.dart';

import 'confirmation_dailogue.dart';

class CartItem {
  final String name;
  final String price;
  final String duration;

  CartItem({required this.name, required this.price, required this.duration});
}

class CartScreen extends StatelessWidget {
  final List<CartItem> cartItems;

  const CartScreen({super.key, required this.cartItems});

  int _parsePrice(String price) {
    return int.tryParse(price.replaceAll(RegExp(r'[^\d]'), '')) ?? 0;
  }

  @override
  Widget build(BuildContext context) {
    int selectedTotal = cartItems.fold(0, (sum, item) => sum + _parsePrice(item.price));
    int additionalFee = 50;
    int convenienceFee = 100;
    int payableAmount = selectedTotal + additionalFee + convenienceFee;
    int totalDisplay = payableAmount;

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text("Cart", style: TextStyle(color: Colors.black)),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _sectionHeader("Your Services Order", actionText: "+ Add more"),
              const SizedBox(height: 10),
              ...cartItems.map((item) => _cartItemTile(context, item)).toList(),

              const SizedBox(height: 20),
              const Text("Offers & Discounts", style: TextStyle(fontWeight: FontWeight.bold)),
              const SizedBox(height: 10),
              _couponTile(),

              const SizedBox(height: 20),
              const Text("Payment Summary", style: TextStyle(fontWeight: FontWeight.bold)),
              const SizedBox(height: 10),
              _summaryBox(selectedTotal, additionalFee, convenienceFee, payableAmount),
            ],
          ),
        ),
      ),
      bottomNavigationBar: _bottomBar(context, totalDisplay),
    );
  }

  Widget _sectionHeader(String title, {String? actionText}) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
        if (actionText != null)
          Text(actionText, style: const TextStyle(color: Color(0xFF9C733C), fontSize: 14)),
      ],
    );
  }

  Widget _cartItemTile(BuildContext context, CartItem item) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 8),
      padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 12),
      decoration: BoxDecoration(
        border: Border(bottom: BorderSide(color: Colors.grey.shade200)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          // Left
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(item.name, style: const TextStyle(fontWeight: FontWeight.bold)),
              const SizedBox(height: 4),
              const Text("For Male", style: TextStyle(fontSize: 13, color: Colors.grey)),
              Text("${item.price} • ${item.duration}", style: const TextStyle(fontSize: 13)),
            ],
          ),
          // Right
          OutlinedButton(
            onPressed: () {
              Navigator.pop(context, item.name); // send back item name to remove
            },
            style: OutlinedButton.styleFrom(
              side: const BorderSide(color: Color(0xFF9C733C)),
              foregroundColor: const Color(0xFF9C733C),
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            ),
            child: const Text("Remove"),
          ),
        ],
      ),
    );
  }

  Widget _couponTile() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(14),
        color: Colors.grey.shade100,
      ),
      child: Row(
        children: const [
          Icon(Icons.local_offer_outlined, color: Colors.black),
          SizedBox(width: 10),
          Expanded(child: Text("Apply Coupon", style: TextStyle(fontSize: 15))),
          Icon(Icons.arrow_forward_ios, size: 14)
        ],
      ),
    );
  }

  Widget _summaryBox(int selectedTotal, int additional, int convenience, int payable) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.grey.shade50,
        borderRadius: BorderRadius.circular(14),
      ),
      child: Column(
        children: [
          _summaryRow("Selected Services", "₹$selectedTotal", showArrow: true),
          _summaryRow("Additional Fee", "₹$additional"),
          _summaryRow("Convenience Fee", "₹$convenience"),
          const Divider(height: 24),
          _summaryRow("Payable Amount", "₹$payable", isBold: true),
        ],
      ),
    );
  }

  Widget _summaryRow(String label, String value, {bool isBold = false, bool showArrow = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              Text(label, style: TextStyle(fontWeight: isBold ? FontWeight.bold : FontWeight.normal)),
              if (showArrow) const Icon(Icons.arrow_forward_ios, size: 12, color: Colors.grey),
            ],
          ),
          Text(value, style: TextStyle(fontWeight: isBold ? FontWeight.bold : FontWeight.normal)),
        ],
      ),
    );
  }

  Widget _bottomBar(BuildContext context, int totalAmount) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      decoration: const BoxDecoration(
        color: Colors.white,
        boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 8)],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text("Total ₹$totalAmount", style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
          ElevatedButton(
            onPressed: () async {
              DateTime? selectedDate = await showDatePicker(
                context: context,
                initialDate: DateTime.now().add(const Duration(days: 1)),
                firstDate: DateTime.now(),
                lastDate: DateTime.now().add(const Duration(days: 365)),
              );

              if (selectedDate != null) {
                TimeOfDay? selectedTime = await showTimePicker(
                  context: context,
                  initialTime: TimeOfDay(hour: 8, minute: 0),
                );

                if (selectedTime != null) {
                  // After selecting both date and time, show confirmation popup
                  DateTime finalDateTime = DateTime(
                    selectedDate.year,
                    selectedDate.month,
                    selectedDate.day,
                    selectedTime.hour,
                    selectedTime.minute,
                  );

                  showDialog(
                    context: context,
                    builder: (context) => BookingConfirmationDialog(
                      bookingDateTime: finalDateTime,
                      services: cartItems.map((e) => e.name).toList(),
                    ),
                  );
                }
              }
            },

            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF9C733C),
              padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 14),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            ),
            child: const Text("Pay", style: TextStyle(fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }
}
