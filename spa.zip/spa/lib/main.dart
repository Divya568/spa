import 'package:flutter/material.dart';
import 'locationScreen.dart';

void main() {
  runApp(SpaApp());
}
class SpaApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Custom AppBar with Search',
      home:LocationScreen(),
    );
  }
}

