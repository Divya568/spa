import 'dart:core';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'cart_screen.dart';

class StoreProfileScreen extends StatefulWidget {
  const StoreProfileScreen({super.key});

  @override
  State<StoreProfileScreen> createState() => _StoreProfileScreenState();
}

class _StoreProfileScreenState extends State<StoreProfileScreen> {
  final Map<String, bool> _expanded = {
    "Massage Therapy": true,
    "Hair Cut Wash & Style": false,
    "Nail Bar": false,
  };
  List<CartItem> _cartItems = [];

  @override
  Widget build(BuildContext context) {
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle.dark,
      child: Scaffold(
        body: Stack(
          children: [
            // Background Image
            Positioned.fill(
              child: Image.network(
                'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRwBVBqPbJl5YNbXAtNS_t8fYhLqCui-W-1hw&s',
                fit: BoxFit.cover,
              ),
            ),

            // Top & Bottom white gradient overlay
            Positioned.fill(
              child: Column(
                children: [
                  Container(height: 200, decoration: BoxDecoration(gradient: _whiteTopGradient())),
                  Expanded(child: Container(color: Colors.white.withOpacity(0.95))),
                ],
              ),
            ),

            // Main Scroll Content
            SafeArea(
              child: SingleChildScrollView(
                padding: const EdgeInsets.only(bottom: 120),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Header
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      child: Row(
                        children: [
                          Icon(Icons.arrow_back_ios, color: Colors.brown.shade800),
                          const SizedBox(width: 8),
                          const Text(" ",
                              style: TextStyle(fontWeight: FontWeight.w600, fontSize: 18)),
                        ],
                      ),
                    ),
                    const SizedBox(height: 36),
                    _storeCard(),
                    const SizedBox(height: 16),
                    _buildChips(),
                    const SizedBox(height: 12),

                    _buildExpandableSection("Massage Therapy", services: [
                      _serviceTile("Swedish Massage", "₹4,000", "60 Mins", "Walk-in"),
                      _serviceTile("Deep Tissue Massage", "₹6,200", "60 Mins", "Walk-in"),
                      _serviceTile("Hot Stone Massage", "₹8,500", "60 Mins", "Homevisit"),
                    ]),
                    _buildExpandableSection("Hair Cut Wash & Style"),
                    _buildExpandableSection("Nail Bar"),
                  ],
                ),
              ),
            ),

            // Bottom Check out bar
            Positioned(
              bottom: 0,
              left: 0,
              right: 0,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
                decoration: const BoxDecoration(
                  color: Colors.white,
                  boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 8)],
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text("${_cartItems.length} Services added", style: const TextStyle(fontWeight: FontWeight.w600)),

                    ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF9C733C),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                      ),
                        onPressed: () async {
                          final removedItemName = await Navigator.push<String>(
                            context,
                            MaterialPageRoute(
                              builder: (context) => CartScreen(cartItems: _cartItems),
                            ),
                          );

                          if (removedItemName != null) {
                            setState(() {
                              _cartItems.removeWhere((item) => item.name == removedItemName);
                            });
                          }


                        },
                      child: const Text("Check out"),
                    ),
                  ],
                ),
              ),
            )
          ],
        ),
      ),
    );
  }

  LinearGradient _whiteTopGradient() => const LinearGradient(
    colors: [Colors.white, Colors.white10],
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
  );

  Widget _storeCard() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 6)],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Row(
            children: [
              CircleAvatar(
                radius: 26,
                backgroundColor: Colors.red,
                child: Text("H", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
              ),
              SizedBox(width: 12),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text("Oasis Spa Haven", style: TextStyle(fontWeight: FontWeight.bold)),
                  SizedBox(height: 4),
                  Row(
                    children: [
                      Icon(Icons.location_on, size: 16, color: Colors.grey),
                      Text(" Madhapur  · 3.5 km  "),
                      Icon(Icons.star, size: 16, color: Colors.amber),
                      Text(" 4.5"),
                    ],
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(height: 14),
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: Colors.green.shade50,
              borderRadius: BorderRadius.circular(10),
            ),
            child: Row(
              children: const [
                Icon(Icons.local_offer, size: 18, color: Colors.green),
                SizedBox(width: 8),
                Expanded(
                  child: Text.rich(
                    TextSpan(
                      text: "Use code ",
                      children: [
                        TextSpan(text: "DSaloon ", style: TextStyle(fontWeight: FontWeight.bold)),
                        TextSpan(text: "Get ₹500 off on orders above 1000/-"),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          )
        ],
      ),
    );
  }

  Widget _buildChips() {
    final filters = ["All", "Home-visit", "Walk-in", "Male", "Female"];
    return Padding(
      padding: const EdgeInsets.only(left: 16),
      child: SizedBox(
        height: 36,
        child: ListView.separated(
          scrollDirection: Axis.horizontal,
          itemCount: filters.length,
          itemBuilder: (_, i) {
            final isSelected = i == 0;
            return Chip(
              label: Text(filters[i]),
              backgroundColor: isSelected ? const Color(0xFFE8D5B5) : Colors.grey.shade200,
              shape: StadiumBorder(
                side: BorderSide(color: isSelected ? const Color(0xFF9C733C) : Colors.grey.shade300),
              ),
            );
          },
          separatorBuilder: (_, __) => const SizedBox(width: 8),
        ),
      ),
    );
  }

  Widget _buildExpandableSection(String title, {List<Widget>? services}) {
    final isOpen = _expanded[title] ?? false;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        children: [
          GestureDetector(
            onTap: () => setState(() => _expanded[title] = !isOpen),
            child: Row(
              children: [
                Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                const Spacer(),
                AnimatedRotation(
                  turns: isOpen ? 0.5 : 0.0,
                  duration: const Duration(milliseconds: 200),
                  child: const Icon(Icons.keyboard_arrow_down, color: Colors.grey),
                ),
              ],
            ),
          ),
          const SizedBox(height: 10),
          if (isOpen && services != null) ...services,
        ],
      ),
    );
  }

  Widget _serviceTile(String name, String price, String duration, String type ) {
    bool selected = _cartItems.any((item) => item.name == name);

    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.brown.shade100),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(name, style: const TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 6),
          const Text(
            "Experience relaxation and stress relief with long, flowing strokes and gentle kneading tech...",
            style: TextStyle(color: Colors.grey, fontSize: 13),
          ),
          const SizedBox(height: 8),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text("$price · $duration · $type", style: const TextStyle(fontSize: 13)),
              ElevatedButton(
                onPressed: () {
                  setState(() {
                    if (selected) {
                      _cartItems.removeWhere((item) => item.name == name);
                    } else {
                      _cartItems.add(CartItem(name: name, price: price, duration: duration));
                    }
                  });
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: selected ? Colors.grey.shade300 : const Color(0xFF9C733C),
                  foregroundColor: selected ? Colors.black : Colors.white,
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6)),
                ),
                child: Text(selected ? "Remove" : "Add"),
              )
            ],
          )
        ],
      ),
    );
  }

}
