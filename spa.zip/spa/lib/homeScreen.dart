import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:spa/details_screen.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: SpaListScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class Spa {
  final String name;
  final String image;
  final String location;
  final String rating;
  final String distance;
  final String discount;
  final String description;
  final String gender;

  Spa({
    required this.name,
    required this.image,
    required this.location,
    required this.rating,
    required this.distance,
    required this.discount,
    required this.description,
    required this.gender,
  });

  factory Spa.fromJson(Map<String, dynamic> json) {
    return Spa(
      name: json['name'] ?? '',
      image: json['image'] ?? '',
      location: json['location'] ?? '',
      rating: json['rating'] ?? '4.5',
      distance: json['distance'] ?? '3.5 km',
      discount: json['discount'] ?? '',
      description: json['description'] ?? '',
      gender: json['gender'] ?? 'Unisex',
    );
  }
}

class SpaListScreen extends StatefulWidget {
  @override
  _SpaListScreenState createState() => _SpaListScreenState();
}

class _SpaListScreenState extends State<SpaListScreen> {
  late Future<List<Spa>> spas;

  Future<List<Spa>> fetchSpas() async {
    final response = await http.get(Uri.parse('https://dummyjson.com/c/65fe-3047-4e48-9aac'));
    if (response.statusCode == 200) {
      final jsonData = json.decode(response.body);
      List spaList = jsonData ?? [];
      return spaList.map((data) => Spa.fromJson(data)).toList();
    } else {
      throw Exception('Failed to load spas');
    }
  }

  @override
  void initState() {
    super.initState();
    spas = fetchSpas();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFF8F5F0),
      body: SafeArea(
        child: Column(
          children: [
            // AppBar and Search Bar
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                children: [
                  Row(
                    children: [
                      Icon(Icons.location_on, color: Colors.brown),
                      SizedBox(width: 5),
                      DropdownButton<String>(
                        value: 'Madhapur',
                        items: ['Madhapur', 'Hitech City']
                            .map((val) => DropdownMenuItem(value: val, child: Text(val)))
                            .toList(),
                        onChanged: (_) {},
                        underline: SizedBox(),
                      ),
                      Spacer(),
                      Icon(Icons.notifications_none),
                    ],
                  ),
                  SizedBox(height: 12),
                  TextField(
                    decoration: InputDecoration(
                      hintText: "Search Spa, Services...",
                      prefixIcon: Icon(Icons.search),
                      filled: true,
                      fillColor: Colors.white,
                      contentPadding: EdgeInsets.symmetric(vertical: 0, horizontal: 20),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: BorderSide.none,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: FutureBuilder<List<Spa>>(
                future: spas,
                builder: (context, snapshot) {
                  if (snapshot.hasData) {
                    return GestureDetector(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) =>  StoreProfileScreen(),
                          ),
                        );
                      },
                      child: ListView.builder(
                        padding: EdgeInsets.symmetric(horizontal: 12),
                        itemCount: snapshot.data!.length,
                        itemBuilder: (context, index) {
                          final spa = snapshot.data![index];
                          return Container(
                            margin: EdgeInsets.only(bottom: 12),
                            padding: EdgeInsets.all(12),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(16),
                              boxShadow: const [
                                BoxShadow(
                                  color: Colors.black12,
                                  blurRadius: 6,
                                  offset: Offset(0, 2),
                                )
                              ],
                            ),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                ClipRRect(
                                  borderRadius: BorderRadius.circular(12),
                                  child: Image.network(
                                    spa.image,
                                    width: 70,
                                    height: 70,
                                    fit: BoxFit.cover,
                                  ),
                                ),
                                SizedBox(width: 12),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        spa.name,
                                        style: const TextStyle(
                                          fontWeight: FontWeight.bold,
                                          fontSize: 16,
                                        ),
                                      ),
                                      SizedBox(height: 4),
                                      Row(
                                        children: [
                                          Icon(Icons.location_on, size: 14, color: Colors.grey),
                                          SizedBox(width: 4),
                                          Expanded(
                                            child: Text(
                                              spa.location,
                                              style: TextStyle(color: Colors.grey[600], fontSize: 12),
                                              overflow: TextOverflow.ellipsis,
                                            ),
                                          ),
                                        ],
                                      ),
                                      SizedBox(height: 4),
                                      Row(
                                        children: [
                                          Icon(Icons.star, color: Colors.orange, size: 16),
                                          SizedBox(width: 4),
                                          Text(spa.rating),
                                          SizedBox(width: 16),
                                          Icon(Icons.place, color: Colors.blueGrey, size: 16),
                                          SizedBox(width: 4),
                                          Text(spa.distance),
                                        ],
                                      ),
                                      if (spa.discount.isNotEmpty)
                                        Padding(
                                          padding: const EdgeInsets.only(top: 4.0),
                                          child: Row(
                                            children: [
                                              Icon(Icons.local_offer, color: Colors.green, size: 14),
                                              SizedBox(width: 4),
                                              Text(
                                                spa.discount,
                                                style: TextStyle(
                                                  fontSize: 12,
                                                  color: Colors.green,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                    ],
                                  ),
                                ),
                                Icon(Icons.favorite_border, color: Colors.brown),
                              ],
                            ),
                          );
                        },
                      ),
                    );
                  } else if (snapshot.hasError) {
                    return Center(child: Text('Failed to load spas'));
                  }
                  return Center(child: CircularProgressIndicator());
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
